func hero(bullets: Int, dragons: Int) -> Bool {
  return bullets >= dragons * 2
}
